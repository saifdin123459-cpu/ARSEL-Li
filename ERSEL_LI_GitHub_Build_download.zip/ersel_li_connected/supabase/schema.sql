-- ERSEL LI: SHD demo wallet schema
-- Run this whole file in Supabase SQL Editor.

create table if not exists public.wallets (
  user_id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'مستخدم',
  balance_cents bigint not null default 100000 check (balance_cents >= 0),
  created_at timestamptz not null default now()
);

create table if not exists public.transfers (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null references auth.users(id),
  recipient_id uuid not null references auth.users(id),
  sender_email text not null,
  recipient_email text not null,
  amount_cents bigint not null check (amount_cents > 0),
  memo text not null default '',
  created_at timestamptz not null default now(),
  constraint different_wallets check (sender_id <> recipient_id)
);

create index if not exists transfers_sender_created_idx
  on public.transfers(sender_id, created_at desc);
create index if not exists transfers_recipient_created_idx
  on public.transfers(recipient_id, created_at desc);

alter table public.wallets enable row level security;
alter table public.transfers enable row level security;

drop policy if exists "read own wallet" on public.wallets;
create policy "read own wallet" on public.wallets
for select to authenticated
using (user_id = auth.uid());

drop policy if exists "read own transfers" on public.transfers;
create policy "read own transfers" on public.transfers
for select to authenticated
using (sender_id = auth.uid() or recipient_id = auth.uid());

-- Wallet creation is server-side via auth trigger. Clients cannot directly
-- insert/update wallet balances or create/edit transfer records.
revoke insert, update, delete on public.wallets from anon, authenticated;
revoke insert, update, delete on public.transfers from anon, authenticated;
grant select on public.wallets to authenticated;
grant select on public.transfers to authenticated;

create or replace function public.create_demo_wallet()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.wallets(user_id, display_name, balance_cents)
  values (
    new.id,
    coalesce(nullif(trim(new.raw_user_meta_data->>'display_name'), ''), 'مستخدم'),
    100000
  )
  on conflict (user_id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created_wallet on auth.users;
create trigger on_auth_user_created_wallet
after insert on auth.users
for each row execute procedure public.create_demo_wallet();

create or replace function public.transfer_shd(
  p_recipient_email text,
  p_amount_cents bigint,
  p_memo text default ''
)
returns jsonb
language plpgsql
security definer
set search_path = public, auth
as $$
declare
  v_sender uuid;
  v_recipient uuid;
  v_sender_email text;
  v_recipient_email text;
  v_sender_balance bigint;
  v_transfer_id uuid;
  v_email text;
begin
  v_sender := auth.uid();
  if v_sender is null then
    raise exception 'يجب تسجيل الدخول أولاً';
  end if;

  if p_amount_cents is null or p_amount_cents <= 0 or p_amount_cents > 100000000 then
    raise exception 'المبلغ غير صالح';
  end if;

  v_email := lower(trim(coalesce(p_recipient_email, '')));
  if v_email = '' then raise exception 'أدخل بريد المستلم'; end if;

  select id, lower(email) into v_recipient, v_recipient_email
  from auth.users
  where lower(email) = v_email
  limit 1;

  if v_recipient is null then raise exception 'لم يتم العثور على حساب بهذا البريد'; end if;
  if v_recipient = v_sender then raise exception 'لا يمكنك التحويل إلى حسابك'; end if;

  select lower(email) into v_sender_email from auth.users where id = v_sender;

  -- Lock both wallet rows in a deterministic order to avoid concurrent double-spends.
  perform 1
  from public.wallets
  where user_id in (v_sender, v_recipient)
  order by user_id
  for update;

  select balance_cents into v_sender_balance
  from public.wallets where user_id = v_sender;

  if v_sender_balance is null then raise exception 'محفظة المرسل غير موجودة'; end if;
  if v_sender_balance < p_amount_cents then raise exception 'الرصيد غير كافٍ'; end if;

  update public.wallets
  set balance_cents = balance_cents - p_amount_cents
  where user_id = v_sender;

  update public.wallets
  set balance_cents = balance_cents + p_amount_cents
  where user_id = v_recipient;

  insert into public.transfers(
    sender_id, recipient_id, sender_email, recipient_email, amount_cents, memo
  ) values (
    v_sender, v_recipient, coalesce(v_sender_email, ''),
    coalesce(v_recipient_email, v_email), p_amount_cents,
    left(coalesce(p_memo, ''), 120)
  )
  returning id into v_transfer_id;

  return jsonb_build_object('transfer_id', v_transfer_id, 'amount_cents', p_amount_cents);
end;
$$;

revoke all on function public.transfer_shd(text, bigint, text) from public, anon;
grant execute on function public.transfer_shd(text, bigint, text) to authenticated;
